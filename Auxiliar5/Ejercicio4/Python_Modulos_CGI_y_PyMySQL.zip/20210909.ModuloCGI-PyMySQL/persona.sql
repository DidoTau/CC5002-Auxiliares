CREATE TABLE persona (
  id int(11) NOT NULL auto_increment,
  nombre varchar(100) NOT NULL,
  apellido varchar(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8
